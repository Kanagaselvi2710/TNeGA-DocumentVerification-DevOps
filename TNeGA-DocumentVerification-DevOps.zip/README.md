# Tamil Nadu Digital Document Verification Portal – DevOps Automation

This project simulates a simple e-governance **Document Verification Portal** using OCR (Optical Character Recognition).  
It demonstrates **DevOps CI/CD automation** using GitHub Actions and Docker.

## 🧱 Features
- Flask web app for document upload and OCR text extraction.
- Dockerized environment.
- Automated CI/CD pipeline using GitHub Actions.
- Basic monitoring guide (Prometheus + Grafana).

## 🧩 Setup
```bash
docker-compose up --build
```
Then open [http://localhost:5000](http://localhost:5000)

## 📈 Monitoring
See `/docs/setup-guide.md` for Prometheus and Grafana setup.
