from flask import Flask, render_template, request
import pytesseract
from PIL import Image
import os

app = Flask(__name__)

@app.route('/', methods=['GET', 'POST'])
def upload_file():
    text = ""
    if request.method == 'POST':
        if 'file' not in request.files:
            return 'No file uploaded!', 400
        file = request.files['file']
        if file.filename == '':
            return 'No selected file!', 400
        image = Image.open(file.stream)
        text = pytesseract.image_to_string(image)
    return render_template('upload.html', text=text)

if __name__ == '__main__':
    app.run(host='0.0.0.0', port=5000)
