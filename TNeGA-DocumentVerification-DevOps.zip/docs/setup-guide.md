# Monitoring Setup Guide

## Prometheus Setup
1. Install Prometheus using Docker:
   ```bash
   docker run -d --name prometheus -p 9090:9090 prom/prometheus
   ```

2. Add a job to monitor your app in `prometheus.yml`:
   ```yaml
   scrape_configs:
     - job_name: 'tnega-app'
       static_configs:
         - targets: ['localhost:5000']
   ```

## Grafana Setup
1. Install Grafana:
   ```bash
   docker run -d -p 3000:3000 grafana/grafana
   ```
2. Add Prometheus as a data source.
3. Import dashboard from `grafana_dashboard.json` (sample).

Now you can monitor your OCR service performance and uptime.
